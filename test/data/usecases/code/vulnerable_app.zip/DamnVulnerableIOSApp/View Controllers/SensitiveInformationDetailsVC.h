//
//  SensitiveInformationDetailsVC.h
//  DamnVulnerableIOSApp
//
//  Created by Prateek Gianchandani on 10/7/14.
//  Copyright (c) 2014 HighAltitudeHacks.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SensitiveInformationDetailsVC : UIViewController

@end
