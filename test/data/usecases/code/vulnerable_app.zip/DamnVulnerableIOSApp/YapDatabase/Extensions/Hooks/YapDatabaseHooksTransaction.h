#import <Foundation/Foundation.h>
#import "YapDatabaseExtensionTransaction.h"


@interface YapDatabaseHooksTransaction : YapDatabaseExtensionTransaction

@end
