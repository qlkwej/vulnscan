#import <Foundation/Foundation.h>


@interface NSDictionary (YapDatabase)

- (BOOL)ydb_containsKey:(id)key;

@end
